(window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["chunk-2d0d0f58"],{"69cb":function(e,c,t){"use strict";t.r(c),
// @license © 2020 Google LLC. Licensed under the Apache License, Version 2.0.
c["default"]=async(e,c={})=>{const t=document.createElement("a");t.download=c.fileName||"Untitled",t.href=URL.createObjectURL(e),t.addEventListener("click",()=>{setTimeout(()=>URL.revokeObjectURL(t.href),3e4)}),t.click()}}}]);
//# sourceMappingURL=chunk-2d0d0f58.dc022e33.js.map