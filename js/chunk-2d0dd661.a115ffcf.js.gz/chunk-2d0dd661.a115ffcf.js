(window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["chunk-2d0dd661"],{"80e8":function(e,i,t){"use strict";t.r(i),
// @license © 2020 Google LLC. Licensed under the Apache License, Version 2.0.
i["default"]=async(e,i={},t=null)=>{i.fileName=i.fileName||"Untitled",t=t||await window.chooseFileSystemEntries({type:"save-file",accepts:[{description:i.description||"",mimeTypes:[e.type],extensions:i.extensions||[""]}]});const n=await t.createWritable();return await n.write(e),await n.close(),t}}}]);
//# sourceMappingURL=chunk-2d0dd661.a115ffcf.js.map